﻿INSERT INTO Members (Name, PhoneNumber, JoinDate, MembershipStatus, FeesStatus)
VALUES ('John Doe', '1234567890', '2025-01-15', 'Active', 'Paid'),
       ('Jane Smith', '2345678901', '2025-02-10', 'Active', 'Unpaid'),
       ('Michael Johnson', '3456789012', '2025-03-05', 'Inactive', 'Paid');
