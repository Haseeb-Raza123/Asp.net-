﻿using System;
using System.Web;
using System.Web.UI;

namespace Prototype
{
    public partial class Logout : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Destroy session variables
            Session.Abandon();
            Session.Clear();

            // Redirect to login page
            Response.Redirect("Login.aspx");
        }
    }
}
