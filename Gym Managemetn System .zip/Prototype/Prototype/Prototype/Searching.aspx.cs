﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Prototype
{
    public partial class Searching : System.Web.UI.Page
    {
        string connectionString = ConfigurationManager.ConnectionStrings["GymDBConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadGrid();
            }
        }

        protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadGrid();
        }

        protected void LoadGrid()
        {
            string category = ddlCategory.SelectedValue;
            string searchText = txtSearch.Text.Trim();
            string query = "";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;

                    if (category == "Members")
                    {
                        query = "SELECT MemberID AS ID, Name, PhoneNumber, JoinDate, MembershipStatus, FeesStatus FROM Members WHERE Name LIKE @SearchText";
                    }
                    else if (category == "Staff")
                    {
                        query = "SELECT StaffID AS ID, FirstName + ' ' + LastName AS Name, PhoneNumber, DOB, JoinDate, City, Email FROM Staff WHERE FirstName LIKE @SearchText OR LastName LIKE @SearchText";
                    }
                    else if (category == "Equipment")
                    {
                        query = "SELECT EquipmentID AS ID, Name, Condition FROM Equipment WHERE Name LIKE @SearchText";
                    }

                    cmd.CommandText = query;
                    cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    // Reset columns dynamically
                    GridView1.Columns.Clear();

                    foreach (DataColumn col in dt.Columns)
                    {
                        GridView1.Columns.Add(new BoundField
                        {
                            DataField = col.ColumnName,
                            HeaderText = col.ColumnName.Replace("_", " ")
                        });
                    }

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            LoadGrid();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            LoadGrid();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            LoadGrid();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
            string name = ((TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0]).Text;
            string category = ddlCategory.SelectedValue;
            string query = "";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@ID", id);

                    if (category == "Members")
                    {
                        query = "UPDATE Members SET Name = @Name WHERE MemberID = @ID";
                        cmd.Parameters.AddWithValue("@Name", name);
                    }
                    else if (category == "Staff")
                    {
                        string[] nameParts = name.Split(' ');
                        string firstName = nameParts.Length > 0 ? nameParts[0] : "";
                        string lastName = nameParts.Length > 1 ? nameParts[1] : "";

                        query = "UPDATE Staff SET FirstName = @FirstName, LastName = @LastName WHERE StaffID = @ID";
                        cmd.Parameters.AddWithValue("@FirstName", firstName);
                        cmd.Parameters.AddWithValue("@LastName", lastName);
                    }
                    else if (category == "Equipment")
                    {
                        query = "UPDATE Equipment SET Name = @Name WHERE EquipmentID = @ID";
                        cmd.Parameters.AddWithValue("@Name", name);
                    }

                    cmd.CommandText = query;
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            GridView1.EditIndex = -1;
            LoadGrid();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
            string category = ddlCategory.SelectedValue;
            string query = "";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.Parameters.AddWithValue("@ID", id);

                    if (category == "Members")
                        query = "DELETE FROM Members WHERE MemberID = @ID";
                    else if (category == "Staff")
                        query = "DELETE FROM Staff WHERE StaffID = @ID";
                    else if (category == "Equipment")
                        query = "DELETE FROM Equipment WHERE EquipmentID = @ID";

                    cmd.CommandText = query;
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            LoadGrid();
        }
    }
}
