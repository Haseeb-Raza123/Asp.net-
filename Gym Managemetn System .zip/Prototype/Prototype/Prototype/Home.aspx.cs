﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace Prototype
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDashboardData();
            }
        }

        private void LoadDashboardData()
        {
            string connStr = WebConfigurationManager.ConnectionStrings["GymDBConnection"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Get total members count
                SqlCommand cmdMembers = new SqlCommand("SELECT COUNT(*) FROM Members", conn);
                int totalMembers = (int)cmdMembers.ExecuteScalar();
                lblTotalMembers.Text = totalMembers.ToString(); // Update on the Total Members card

                // Get total staff count
                SqlCommand cmdStaff = new SqlCommand("SELECT COUNT(*) FROM Staff", conn);
                int totalStaff = (int)cmdStaff.ExecuteScalar();
                lblTotalStaff.Text = totalStaff.ToString(); // Display on the Total Staff card

                // Get total equipment count
                SqlCommand cmdEquipment = new SqlCommand("SELECT COUNT(*) FROM Equipment", conn);
                int totalEquipment = (int)cmdEquipment.ExecuteScalar();
                lblTotalEquipment.Text = totalEquipment.ToString(); // Display on the Equipment card
            }
        }
    }
}
