﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace Prototype
{
    public partial class Staff : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["Message"] != null)
                {
                    lblMessage.Text = Session["Message"].ToString();
                    Session["Message"] = null; // Clear message after displaying once
                }
                else
                {
                    lblMessage.Text = "";
                }
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();
            string phone = txtPhone.Text.Trim();
            string dobText = txtDOB.Text.Trim();
            string joinDateText = txtJoinDate.Text.Trim();
            string city = ddlCity.SelectedValue;
            string email = txtEmail.Text.Trim();

            // Check if required fields are empty
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) ||
                string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(dobText) ||
                string.IsNullOrEmpty(joinDateText) || string.IsNullOrEmpty(city) ||
                string.IsNullOrEmpty(email))
            {
                Session["Message"] = "❌ Please fill all the required fields.";
                Response.Redirect(Request.RawUrl); // Refresh page
                return;
            }

            // Validate date formats
            if (!DateTime.TryParse(dobText, out DateTime dob) || !DateTime.TryParse(joinDateText, out DateTime joinDate))
            {
                Session["Message"] = "❌ Invalid date format. Use YYYY-MM-DD.";
                Response.Redirect(Request.RawUrl);
                return;
            }

            // Database connection
            string connStr = WebConfigurationManager.ConnectionStrings["GymDBConnection"].ConnectionString;
            string insertQuery = "INSERT INTO Staff (FirstName, LastName, PhoneNumber, DOB, JoinDate, City, Email) " +
                                 "VALUES (@FirstName, @LastName, @PhoneNumber, @DOB, @JoinDate, @City, @Email)";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(insertQuery, conn);
                    cmd.Parameters.AddWithValue("@FirstName", firstName);
                    cmd.Parameters.AddWithValue("@LastName", lastName);
                    cmd.Parameters.AddWithValue("@PhoneNumber", phone);
                    cmd.Parameters.AddWithValue("@DOB", dob);
                    cmd.Parameters.AddWithValue("@JoinDate", joinDate);
                    cmd.Parameters.AddWithValue("@City", city);
                    cmd.Parameters.AddWithValue("@Email", email);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    Session["Message"] = rowsAffected > 0 ? "✅ Registration Successful!" : "❌ Registration Failed.";
                }
                catch (Exception ex)
                {
                    Session["Message"] = "❌ Database Error: " + ex.Message;
                }
                finally
                {
                    Response.Redirect(Request.RawUrl);
                }
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtPhone.Text = "";
            txtDOB.Text = "";
            txtJoinDate.Text = "";
            txtEmail.Text = "";
            ddlCity.SelectedIndex = 0;
            lblMessage.Text = "";
        }
    }
}
