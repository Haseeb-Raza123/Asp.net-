﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Web.UI;

namespace Prototype
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Text = ""; // Clear error message on page load
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();
            string hashedPassword = HashPassword(password); // Hash the entered password

            string connectionString = ConfigurationManager.ConnectionStrings["GymDBConnection"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT Role FROM Users WHERE Email = @Email AND Password = @Password";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", hashedPassword);

                try
                {
                    con.Open();
                    object roleObj = cmd.ExecuteScalar();

                    if (roleObj != null) // Ensure role is fetched
                    {
                        string userRole = roleObj.ToString().Trim(); // Trim any extra spaces
                        Session["UserRole"] = userRole;
                        Session["UserEmail"] = email;

                        lblMessage.Text = "✅ Login Successful, Role: " + userRole;
                        lblMessage.ForeColor = System.Drawing.Color.Green;

                        // Redirect based on role
                        if (userRole.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                        {
                            Response.Redirect("Home.aspx", false);
                        }
                        else
                        {
                            Response.Redirect("Users.aspx", false);
                        }
                    }
                    else
                    {
                        lblMessage.Text = "❌ Invalid credentials or role not assigned!";
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                    }
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "⚠️ Database error: " + ex.Message;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                }
            }
        }

        // Hash password using SHA-256
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
