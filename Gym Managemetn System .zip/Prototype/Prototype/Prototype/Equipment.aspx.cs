﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Prototype
{
    public partial class Equipment : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["GymDBConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadEquipmentData();
            }
        }

        protected void btnAddEquipment_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEquipmentName.Text) ||
                string.IsNullOrWhiteSpace(ddlCategory.SelectedValue) ||
                string.IsNullOrWhiteSpace(txtQuantity.Text) ||
                string.IsNullOrWhiteSpace(ddlCondition.SelectedValue))
            {
                Response.Write("<script>alert('All fields are required.');</script>");
                return;
            }

            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "INSERT INTO Equipment (Name, Category, Quantity, Condition) VALUES (@Name, @Category, @Quantity, @Condition)";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Name", txtEquipmentName.Text.Trim());
                    cmd.Parameters.AddWithValue("@Category", ddlCategory.SelectedValue);
                    cmd.Parameters.AddWithValue("@Quantity", int.Parse(txtQuantity.Text.Trim()));
                    cmd.Parameters.AddWithValue("@Condition", ddlCondition.SelectedValue);

                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();

                    if (rowsAffected > 0)
                    {
                        Response.Write("<script>alert('Equipment added successfully!');</script>");
                        LoadEquipmentData();
                    }
                    else
                    {
                        Response.Write("<script>alert('Error adding equipment. Try again.');</script>");
                    }
                }
            }
        }

        private void LoadEquipmentData()
        {
            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "SELECT Name, Category, Quantity, Condition FROM Equipment";
                using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    gvEquipment.DataSource = dt;
                    gvEquipment.DataBind();
                }
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtEquipmentName.Text = "";
            ddlCategory.SelectedIndex = 0;
            txtQuantity.Text = "";
            ddlCondition.SelectedIndex = 0;
        }
    }
}
