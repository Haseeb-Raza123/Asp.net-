﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace Prototype
{
    public partial class Users : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] == null)
            {
                Response.Redirect("Login.aspx"); // Redirect if not logged in
            }

            lblUserName.Text = Session["Username"].ToString(); // Display logged-in user's name

            if (!IsPostBack)
            {
                LoadUserDetails();
            }
        }

        private void LoadUserDetails()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["GymDBConnection"].ConnectionString;
            string userEmail = Session["Username"].ToString(); // Using Email/Username from Session

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT FullName, Email, Phone, Address, DateOfBirth, JoiningDate, MembershipStatus, FeesStatus FROM Users WHERE Username = @Username OR Email = @Username";
                
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Username", userEmail);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        gvUserDetails.DataSource = dt;
                        gvUserDetails.DataBind();
                    }
                    else
                    {
                        // If no data found, show a message
                        gvUserDetails.EmptyDataText = "No membership details found!";
                        gvUserDetails.DataBind();
                    }
                }
            }
        }
    }
}
