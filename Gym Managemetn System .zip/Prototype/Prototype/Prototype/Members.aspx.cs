﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace Prototype
{
    public partial class Members : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblWelcome.Text = "";
            }
        }

        // Register button click event
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            // Get values from the form controls
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();
            string phone = txtPhone.Text.Trim();
            string dobText = txtDOB.Text.Trim();
            string joinDateText = txtJoinDate.Text.Trim();
            string city = ddlCity.SelectedValue;
            string email = txtPhone0.Text.Trim();

            // Check if any required field is empty
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) ||
                string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(city) || string.IsNullOrEmpty(email))
            {
                lblWelcome.Text = "❌ Please fill all the required fields.";
                return;
            }

            // Ensure DateTime values are correctly parsed
            DateTime dob, joinDate;
            if (!DateTime.TryParse(dobText, out dob) || !DateTime.TryParse(joinDateText, out joinDate))
            {
                lblWelcome.Text = "❌ Invalid date format. Use YYYY-MM-DD.";
                return;
            }

            // Connection string from Web.config
            string connStr = WebConfigurationManager.ConnectionStrings["GymDBConnection"].ConnectionString;

            // Insert query to add member to the database
            string insertQuery = "INSERT INTO Members (Name, PhoneNumber, JoinDate, MembershipStatus, FeesStatus) " +
                                 "VALUES (@Name, @PhoneNumber, @JoinDate, @MembershipStatus, @FeesStatus)";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(insertQuery, conn);

                    // Use parameters to avoid SQL injection
                    cmd.Parameters.AddWithValue("@Name", firstName + " " + lastName);
                    cmd.Parameters.AddWithValue("@PhoneNumber", phone);
                    cmd.Parameters.AddWithValue("@JoinDate", joinDate);
                    cmd.Parameters.AddWithValue("@MembershipStatus", "Active"); // Default status
                    cmd.Parameters.AddWithValue("@FeesStatus", "Unpaid"); // Default status

                    // Execute the command
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        lblWelcome.Text = "✅ Registration Successful! Welcome " + firstName + " " + lastName + "!";
                    }
                    else
                    {
                        lblWelcome.Text = "❌ Registration unsuccessful. Please try again.";
                    }
                }
                catch (Exception ex)
                {
                    lblWelcome.Text = "❌ Database Error: " + ex.Message;
                }
            }
        }

        // Reset button click event to clear the form
        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtPhone.Text = "";
            txtDOB.Text = "";
            txtJoinDate.Text = "";
            ddlCity.SelectedIndex = 0;
            txtPhone0.Text = "";
            lblWelcome.Text = ""; // Clear the message
        }
    }
}