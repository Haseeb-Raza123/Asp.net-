﻿using System;
using System.Web.UI;

namespace Prototype
{
    public partial class ForgotPassword : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                verificationPanel.Visible = false;
                resetPasswordPanel.Visible = false;
            }
        }

        protected void btnSendCode_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();

            if (!string.IsNullOrEmpty(email))
            {
                lblMessage.Text = "A verification code has been sent to your email.";
                lblMessage.ForeColor = System.Drawing.Color.Green;

                verificationPanel.Visible = true;
            }
            else
            {
                lblMessage.Text = "Please enter a valid registered email.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void btnVerifyCode_Click(object sender, EventArgs e)
        {
            string verificationCode = txtCode.Text.Trim();

            if (!string.IsNullOrEmpty(verificationCode))
            {
                lblMessage.Text = "Verification successful. You can now reset your password.";
                lblMessage.ForeColor = System.Drawing.Color.Green;

                resetPasswordPanel.Visible = true;
            }
            else
            {
                lblMessage.Text = "Invalid verification code. Try again.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void btnResetPassword_Click(object sender, EventArgs e)
        {
            string newPassword = txtNewPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;

            if (newPassword == confirmPassword && !string.IsNullOrEmpty(newPassword))
            {
                lblMessage.Text = "Your password has been successfully reset!";
                lblMessage.ForeColor = System.Drawing.Color.Green;

                Response.Redirect("Login.aspx");
            }
            else
            {
                lblMessage.Text = "Passwords do not match. Please try again.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}
