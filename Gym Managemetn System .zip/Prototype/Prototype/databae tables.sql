﻿CREATE TABLE Members (
    MemberID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    PhoneNumber NVARCHAR(20) NOT NULL,
    JoinDate DATE NOT NULL,
    MembershipStatus NVARCHAR(50) NOT NULL,
    FeesStatus NVARCHAR(50) NOT NULL
);
CREATE TABLE Staff (
    StaffID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Role NVARCHAR(50) NOT NULL,
    Salary DECIMAL(10, 2) NOT NULL
);
CREATE TABLE Equipment (
    EquipmentID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Quantity INT NOT NULL,
    Condition NVARCHAR(50) NOT NULL
);
CREATE TABLE Payments (
    PaymentID INT IDENTITY(1,1) PRIMARY KEY,
    MemberID INT FOREIGN KEY REFERENCES Members(MemberID),
    Amount DECIMAL(10, 2) NOT NULL,
    PaymentDate DATE NOT NULL
);
