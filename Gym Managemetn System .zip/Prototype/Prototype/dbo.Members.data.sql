﻿SET IDENTITY_INSERT [dbo].[Members] ON
INSERT INTO [dbo].[Members] ([MemberID], [Name], [PhoneNumber], [JoinDate], [MembershipStatus], [FeesStatus]) VALUES (2, N'Haseeb Raza', N'03086187560', N'2024-10-30', N'Active', N'Unpaid')
SET IDENTITY_INSERT [dbo].[Members] OFF
