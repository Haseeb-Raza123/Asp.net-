﻿SELECT * FROM Staff;
